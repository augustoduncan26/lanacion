<?php
define('G_SERVIDOR','localhost');   //Server
define('G_BASEDATOS','swapi_db');   //Database
define('G_USUARIO','root');         //User
define('G_CLAVE','');               //Password
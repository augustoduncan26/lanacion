<?php
/*
// // init curl object        
$ch = curl_init();

// define options
$optArray = array(
    CURLOPT_URL => 'https://swapi.dev/api/starships/',
    CURLOPT_RETURNTRANSFER => true
);

// apply those options
curl_setopt_array($ch, $optArray);

// execute request and get response
$result = curl_exec($ch);
echo "<pre>";
var_dump(json_decode($result));
*/
